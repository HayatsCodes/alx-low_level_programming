Let's learn about dynamic memory allocation
