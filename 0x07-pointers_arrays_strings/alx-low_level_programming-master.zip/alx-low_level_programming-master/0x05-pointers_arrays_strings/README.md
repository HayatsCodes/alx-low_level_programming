# 0x05. C -Pointers, arrays and strings 

## 0. reset_to_98

**function that takes a pointer to an `int` as a parameter and updates the value it points to to 98**

## 1. swap_int

**function that swaps the values of two integers**

## 2. _strlen

**function that returns the length of a string**

## 3. _puts

**prints a string followed by a new line to `stdout`**

## 4. print_rev

**prints a string in reverse followed by a new line**puts_half

## 5. rev_string

**reverses a string**

## 6. puts2

**prints every other character of a string, starting with the first character, followed by a new line**

## 7. puts_half

**prints half of a string followed by a new line**

## 8. print_array

**prints n elements of an array of integers followed by a new line**

## 9. _strcpy

**Copies the string pointed to by src, including the terminating null byte to the buffer pointed to by dest**

> - Returns pointer to dest

