#include "main.h"

/**
 * print_alphabet - prints alphabet in lowercase
 * print alphabet a to z
 * Return: Always 0.
 */

void print_alphabet(void)
{
	char c = 'a';

	while (c <= 'z')
	{
		_putchar(c);
		c++;
	}
	_putchar('\n');
}
