#include "main.h"

/**
 * add - add two integers
 * @n: first number to add
 * @m: second number to add
 * Return: returns the result of the addition
 */
int add(int n, int m)
{
	int sum;

	sum = n + m;
	return (sum);
}
