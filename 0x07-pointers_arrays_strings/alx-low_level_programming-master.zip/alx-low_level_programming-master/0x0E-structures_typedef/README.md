C structures typedef
