Let's explore the argc and **argv arguments in depth.
