
task for static libraries.
