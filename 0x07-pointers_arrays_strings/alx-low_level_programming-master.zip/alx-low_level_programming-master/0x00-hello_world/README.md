Explanation of each script coming soon
