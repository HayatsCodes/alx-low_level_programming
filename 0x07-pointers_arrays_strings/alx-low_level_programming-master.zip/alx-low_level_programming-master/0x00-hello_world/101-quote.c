#include <stdio.h>

/**
 * main - entry point
 * print text to standard error
 * Return: 1 if successful
 */
int main(void)
{
	fprintf(stderr, "and that piece of art is useful\" - Dora Korpar, ");
	fprintf(stderr, "2015-10-19\n");
	return (1);
}
