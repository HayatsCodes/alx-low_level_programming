#include <stdio.h>

/**
 * main - entry point
 * print all possible combination of single digit numbers
 * Return: Alwasy 0 (Success)
 */
int main(void)
{
	int n;

	for (n = 48; n < 58; n++)
	{
		putchar(n);
		if (n != 57)
		{
			putchar(',');
			putchar(' ');
		}
	}
	putchar('\n');
	return (0);
}
