
In this project, I learned to use recursion in C to satisfy a condition rather than a loop.
