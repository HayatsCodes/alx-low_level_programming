#ifndef FUNCTION_LIKE_MICRO_H
#define FUNCTION_LIKE_MICRO_H
#define ABS(x) ((x) < 0 ? -(x) : (x))
#endif
