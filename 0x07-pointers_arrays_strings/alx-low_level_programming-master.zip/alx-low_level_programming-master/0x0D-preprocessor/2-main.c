#include <stdio.h>

/**
 * main - print source file name
 * Return: always 0
 */

int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
